#coding=utf-8
import pygame
from pygame.locals import * #必须要加
import time
import random



#玩家飞机类
class PlayerPlane:
	def __init__(self,screen):

		self.name="player"
		#飞机图片
		planeImage="./feiji/hero.gif"
		self.image=pygame.image.load(planeImage).convert()

		#设置默认的坐标
		self.x=200
		self.y=600
		#设置速度
		self.speed=5
		#设置飞机名称
		self.planeName="player"
		#飞机的子弹属性
		self.bullet=[]

		self.screen=screen

	#将飞机显示出来
	def draw(self):
		self.screen.blit(self.image,(self.x,self.y))
		#显示子弹
		for temp in self.bullet:
			temp.draw()

	#键盘控制飞机
	def keyHandle(self,keyValue):
		if keyValue=="left":
			if self.x>=0:
				self.x-=20
		if keyValue=="right":
			if self.x<=380:
				self.x+=20
		if keyValue=="space":
			self.bullet.append(Bullet(self.screen,self.name,self.x+41,self.y-18))



#子弹类
class Bullet:
	def __init__(self,screen,planeName,x,y):
		self.planeName=planeName
		#子弹图片,判断是玩家飞机还是敌机
		if self.planeName=="player":
			bulletImage="./feiji/bullet-3.gif"
			self.image=pygame.image.load(bulletImage).convert()
		elif self.planeName=="enemyPlane":
			bulletImage="./feiji/bullet-1.gif"
			self.image=pygame.image.load(bulletImage).convert()

		#子弹的坐标
		self.x=x
		self.y=y

		self.screen=screen


	def draw(self):
		self.screen.blit(self.image,(self.x,self.y))
		#子弹移动，判断是玩家飞机还是敌机
		if self.planeName=="player":
			self.y-=4
		elif self.planeName=="enemyPlane":
			self.y+=4


#敌方飞机类  
class EnemyPlane:
	def __init__(self,screen,x=0,y=0):

		self.name="enemyPlane"
		#敌机图片
		enemyPlaneImage="./feiji/enemy-1.gif"
		self.image=pygame.image.load(enemyPlaneImage).convert()

		#敌机的坐标
		self.x=x
		self.y=y

		#移动方向
		self.direction="right"

		#敌机的子弹属性
		self.bullet=[]

		self.screen=screen


	def draw(self):
		self.screen.blit(self.image,(self.x,self.y))
		
		for temp in self.bullet:
			temp.draw()
		
	def move(self):
		if self.direction=="right":
			self.x+=4
		elif self.direction=="left":
			self.x-=4

		if self.x>430:
			self.direction="left"
		elif self.x<0:
			self.direction="right"
		
		#敌方飞机发射子弹
		#降低敌机发射子弹频率
		randomNum=random.randint(1,100)
		if randomNum in [1,50,99]:
			self.bullet.append(Bullet(screen,self.name,self.x+25, self.y+40))
		




#程序的开始入口
if __name__ == '__main__':
	screen=pygame.display.set_mode((480,890),0,32)
	bgImageFile="./feiji/background.png"
	background=pygame.image.load(bgImageFile).convert()
	
	#创建玩家飞机
	player=PlayerPlane(screen)
	#创建敌机
	enemyPlane=EnemyPlane(screen)

	while True:
		screen.blit(background,(0,0))
		#添加事件：监测键盘
		for event in pygame.event.get():
			if event.type==QUIT:
				exit()
			elif event.type==KEYDOWN:
				if event.key==K_a or event.key==K_LEFT:
					player.keyHandle("left")
				elif event.key==K_d or event.key==K_RIGHT:
					player.keyHandle("right")
				elif event.key==K_SPACE:
					player.keyHandle("space")
		
		#将飞机画到屏幕上
		player.draw()

		#将敌机显示
		enemyPlane.draw()
		#敌机移动
		enemyPlane.move()
		
		pygame.display.update()
		time.sleep(0.01)#延迟，降低cpu负荷

